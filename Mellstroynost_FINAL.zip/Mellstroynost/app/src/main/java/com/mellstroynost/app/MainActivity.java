package com.mellstroynost.app;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private static final int PERMISSION_REQUEST = 100;

    // Regular sounds: title -> raw resource name
    private final String[][] sounds = {
            {"Ам ам ам", "am_am_am"},
            {"Всем привет, с вами блогер Меллстрой!", "vsem_privet_s_vami_bloger_mellstroy"},
            {"Меллстой орёт и умирает", "mellstoy_oret_i_umiraet"},
            {"Мелл орёт 1", "mell_oret1"},
            {"Ёбаный чемодан", "ebanyy_chemodan"},
            {"Меллстрой орёт 2 громко", "mellstroy_oret2_gromko"},
            {"Меллстрой орёт медленно", "mellstroy_oret_medlenno_pohozhe_na_krik_gde_on_umiraet"},
            {"Омайгадебал", "omaygadebal"},
            {"Омайгад. Нихуя", "omaygad_nihuya"},
            {"Самбуку пер", "sambuku_per"},
            {"Привет Артур", "privet_artur"},
            {"Я уже красный!", "ya_uzhe_krasnyy"},
            {"Сиксевен нах", "sikseven_nah"}
    };

    // Mashups
    private final String[][] mashups = {
            {"Мама птица и птенцы (Цой)", "mama_ptitsa_i_ptentsy_meshap_mellstroya_na_leg_pesnyu_tsoya"},
            {"Зажечь огни земли", "mellstroy_meshap_zazhech_ogni_zemli"},
            {"Кукла Колдуна", "mell_meshae_na_pesnyu_kukla_kolduna"},
            {"Sonic Speed", "mellstroy_sonic_speed_meshap"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestStoragePermission();

        GridLayout gridSounds = findViewById(R.id.gridSounds);
        GridLayout gridMashups = findViewById(R.id.gridMashups);

        for (String[] item : sounds) {
            addSoundButton(gridSounds, item[0], item[1]);
        }
        for (String[] item : mashups) {
            addSoundButton(gridMashups, item[0], item[1]);
        }
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST);
            }
        }
    }

    private void addSoundButton(GridLayout grid, String title, String resName) {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setGravity(Gravity.CENTER_HORIZONTAL);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.setMargins(8, 8, 8, 16);
        container.setLayoutParams(params);

        // Title above button
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(0xFFFFFFFF);
        label.setTextSize(12);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(3);
        label.setPadding(4, 0, 4, 8);
        container.addView(label);

        // Round red button
        ImageButton btn = new ImageButton(this);
        int size = (int) (100 * getResources().getDisplayMetrics().density);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(size, size);
        btn.setLayoutParams(btnParams);
        btn.setBackground(ContextCompat.getDrawable(this, R.drawable.button_bg));
        btn.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        btn.setPadding(8, 8, 8, 8);
        btn.setContentDescription(title);

        // Обычный клик — воспроизвести
        btn.setOnClickListener(v -> playSound(resName));

        // Долгое нажатие — скачать
        btn.setOnLongClickListener(v -> {
            downloadSound(resName, title);
            return true;
        });

        container.addView(btn);

        // Подсказка
        TextView hint = new TextView(this);
        hint.setText("удерж. = скачать");
        hint.setTextColor(0xFF666666);
        hint.setTextSize(10);
        hint.setGravity(Gravity.CENTER);
        container.addView(hint);

        grid.addView(container);
    }

    private void playSound(String resName) {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
            int resId = getResources().getIdentifier(resName, "raw", getPackageName());
            if (resId == 0) {
                Toast.makeText(this, "Файл не найден: " + resName, Toast.LENGTH_SHORT).show();
                return;
            }
            mediaPlayer = MediaPlayer.create(this, resId);
            if (mediaPlayer != null) {
                mediaPlayer.setOnCompletionListener(mp -> {
                    mp.release();
                    mediaPlayer = null;
                });
                mediaPlayer.start();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка воспроизведения", Toast.LENGTH_SHORT).show();
        }
    }

    private void downloadSound(String resName, String title) {
        try {
            int resId = getResources().getIdentifier(resName, "raw", getPackageName());
            if (resId == 0) {
                Toast.makeText(this, "Файл не найден", Toast.LENGTH_SHORT).show();
                return;
            }

            String fileName = title.replaceAll("[^a-zA-Zа-яА-Я0-9 ]", "").trim() + ".mp3";
            if (fileName.length() < 5) fileName = resName + ".mp3";

            InputStream in = getResources().openRawResource(resId);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ MediaStore
                ContentValues values = new ContentValues();
                values.put(MediaStore.Audio.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg");
                values.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Меллстройность");

                android.net.Uri uri = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    OutputStream out = getContentResolver().openOutputStream(uri);
                    if (out != null) {
                        byte[] buffer = new byte[4096];
                        int read;
                        while ((read = in.read(buffer)) != -1) {
                            out.write(buffer, 0, read);
                        }
                        out.close();
                        Toast.makeText(this, "Скачано в Музыка/Меллстройность", Toast.LENGTH_LONG).show();
                    }
                }
            } else {
                // Старые Android
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "Меллстройность");
                if (!dir.exists()) dir.mkdirs();
                File outFile = new File(dir, fileName);
                FileOutputStream out = new FileOutputStream(outFile);
                byte[] buffer = new byte[4096];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
                out.close();
                Toast.makeText(this, "Скачано: " + outFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
            }
            in.close();
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка скачивания: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
