package com.mellstroynost.app;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;

    // Regular sounds: title -> raw resource name
    private final String[][] sounds = {
            {"Ам ам ам", "am_am_am"},
            {"Всем привет, с вами блогер Меллстрой!", "vsem_privet_s_vami_bloger_mellstroy"},
            {"Меллстой орёт и умирает", "mellstoy_oret_i_umiraet"},
            {"Мелл орёт 1", "mell_oret1"},
            {"Ёбаный чемодан", "ebanyy_chemodan"},
            {"Меллстрой орёт 2 громко", "mellstroy_oret2_gromko"},
            {"Меллстрой орёт медленно", "mellstroy_oret_medlenno_pohozhe_na_krik_gde_on_umiraet"},
            {"Омайгадебал", "omaygadebal"},
            {"Омайгад. Нихуя", "omaygad_nihuya"},
            {"Самбуку пер", "sambuku_per"},
            {"Привет Артур", "privet_artur"},
            {"Я уже красный!", "ya_uzhe_krasnyy"},
            {"Сиксевен нах", "sikseven_nah"}
    };

    // Mashups
    private final String[][] mashups = {
            {"Мама птица и птенцы (Цой)", "mama_ptitsa_i_ptentsy_meshap_mellstroya_na_leg_pesnyu_tsoya"},
            {"Зажечь огни земли", "mellstroy_meshap_zazhech_ogni_zemli"},
            {"Кукла Колдуна", "mell_meshae_na_pesnyu_kukla_kolduna"},
            {"Sonic Speed", "mellstroy_sonic_speed_meshap"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GridLayout gridSounds = findViewById(R.id.gridSounds);
        GridLayout gridMashups = findViewById(R.id.gridMashups);

        for (String[] item : sounds) {
            addSoundButton(gridSounds, item[0], item[1]);
        }
        for (String[] item : mashups) {
            addSoundButton(gridMashups, item[0], item[1]);
        }
    }

    private void addSoundButton(GridLayout grid, String title, String resName) {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setGravity(Gravity.CENTER_HORIZONTAL);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.setMargins(8, 8, 8, 16);
        container.setLayoutParams(params);

        // Title above button
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(0xFFFFFFFF);
        label.setTextSize(12);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(3);
        label.setPadding(4, 0, 4, 8);
        container.addView(label);

        // Round red button
        ImageButton btn = new ImageButton(this);
        int size = (int) (100 * getResources().getDisplayMetrics().density);
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(size, size);
        btn.setLayoutParams(btnParams);
        btn.setBackground(ContextCompat.getDrawable(this, R.drawable.button_bg));
        btn.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        btn.setPadding(12, 12, 12, 12);
        btn.setContentDescription(title);

        btn.setOnClickListener(v -> playSound(resName));

        container.addView(btn);
        grid.addView(container);
    }

    private void playSound(String resName) {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
            int resId = getResources().getIdentifier(resName, "raw", getPackageName());
            if (resId == 0) {
                Toast.makeText(this, "Файл не найден: " + resName, Toast.LENGTH_SHORT).show();
                return;
            }
            mediaPlayer = MediaPlayer.create(this, resId);
            if (mediaPlayer != null) {
                mediaPlayer.setOnCompletionListener(mp -> {
                    mp.release();
                    mediaPlayer = null;
                });
                mediaPlayer.start();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка воспроизведения", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
